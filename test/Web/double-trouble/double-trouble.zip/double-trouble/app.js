const express = require('express');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const SECRET = 'SL30342JT223KDEOGRGOPK3KEYWETOIJ2REGJRWEOGIJ4HG890J34GLKERGJERIHOJ';

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/admin', (req, res) => {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).send("Missing token");

  const token = auth.split(' ')[1];

  try {
    const decoded = jwt.verify(token, SECRET, { algorithms: ['HS256'] });

    if (decoded.role === 'admin') {
      const flag = fs.readFileSync('flag.txt', 'utf8');
      return res.send(`Welcome, admin. Here's your flag:\n\n${flag}`);
    } else {
      return res.status(403).send("Access denied. Admins only.");
    }

  } catch (e) {
    return res.status(401).send("Invalid token");
  }
});

app.listen(PORT, () => {
  console.log(`Challenge running at http://localhost:${PORT}`);
});
