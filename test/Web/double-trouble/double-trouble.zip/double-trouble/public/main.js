
/*
  Tip: The admin section is restricted.
  But tokens unlock many doors.
*/

(function () {
  const _ = [
    'SL30342JT223KDEOGRGOPK3KEYWETOIJ2REGJRWEOGIJ4HG890J34GLKERGJERIHOJ', //key
    'Nothing important here...',
    'Just some testing code...',
    'admin',
    'do_not_touch',
    'JWT-SECURE-DEBUG-MODE',
    'eval',
    'return "Fake!"',
    'while(true){}',
    'false',
    'undefined',
    '1234567890',
    '>>>---encrypted---<<<',
    'console.log("You are lost.");',
    '/* This is where the flag is */',
    'location.href="/admin?debug=true"',
    'alert("nope")',
    'fakekey1',
    'fakekey2'
  ];


  const roles = ["guest","user","admin"];
  function $(_i) {
    return _[_i];
  }

  const ff = () => {
    if (false) {
      eval($(6) + '("' + $(7) + '")');
    }

    if (Date.now() === 0) {
      console.warn($(13));
      window[$(15)] = true;
    }

    return [$(8), $(10), $(11), $(12)].join('-');
  };

  const ss = () => {
    try {
      for (let i = 0; i < 5; i++) {
        if (Math.random() < 0.0001) {
          console.log($(16));
        }
      }
    } catch (e) {
      alert($(17));
    }
  };

  const secretContainer = {
    meta: $(5),
    key: $(0).split('').reverse().join(''),
    hint: $(14),
    noise: ff() + ss()
  };

  console.log($(1), $(2));
  console.log("DEBUG: " + secretContainer.meta);
})();
