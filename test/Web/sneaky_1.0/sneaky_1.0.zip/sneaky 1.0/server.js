const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (username === 'ctfplayer' && password === 'hunter2') {
    return res.redirect('/admin');
  }

  return res.send('Invalid credentials. Try again.');
});

app.get('/admin', (req, res) => {
  const flag = fs.readFileSync('flag.txt', 'utf8');
  res.send(`<h1>Welcome, admin!</h1><pre>${flag}</pre>`);
});

app.listen(PORT, () => {
  console.log(`Challenge running on http://localhost:${PORT}`);
});